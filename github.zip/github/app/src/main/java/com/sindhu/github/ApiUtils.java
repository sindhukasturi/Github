package com.sindhu.github;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ApiUtils {

    private static final String BASE_URL = "https://api.github.com/repos/";

    public static Repository fetchRepositoryDetails(String ownerName, String repoName) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(BASE_URL + ownerName + "/" + repoName)
                    .build();
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                Gson gson = new Gson();
                return gson.fromJson(responseBody, Repository.class);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

