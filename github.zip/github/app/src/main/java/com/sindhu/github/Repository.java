package com.sindhu.github;

public class Repository {


        private String name;
        private String description;
        private String repoUrl;

        public Repository(String name, String description, String repoUrl) {
            this.name = name;
            this.description = description;
            this.repoUrl=repoUrl;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }
        public String getRepoUrl(){
            return repoUrl;
        }
}
